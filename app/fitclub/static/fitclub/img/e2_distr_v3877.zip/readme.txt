License: http://blogengine.ru/get/

To each copy of Aegea applies the license which is the latest at the moment of installation or update.

Thanks to
Arseny Sharoglazov for security audit of version 2.10, https://twitter.com/_mohemiv
Evgeniy Lazarev for help with version 2.9 development, https://eugene-lazarev.ru/
Victor Koreysha for multiple improvements in comments
Roman Parpalak for “Rose” search engine, https://written.ru/
Igor Adamenko for local autosaving and much more, https://igoradamenko.com/
Ilya Straykov for help with version 2.5 development, http://straykov.ru/
Artem Polikarpov for brilliant Fotorama, http://fotorama.io/
Ivan Sagalaev for Highlight.js, http://highlightjs.org/
Murat Schidakov for help with tags entry UI implementation and support
Igor Vasilkovsky for the backup system implementation

and also to
Alexander Karpinsky, Artem Sapegin, Ivan Zviahih, Ivan Scholokov, Maxim Ilyahov, Ilya Gelman, Dmitry Kirsanov, Evgeny Stepanischev, Julia Shabunio, Dmitry Smirnov

- - - - -

Лицензия: http://blogengine.ru/get/

К каждой инсталляции Эгеи применима та лицензия, которая была самой свежей на момент установки или последнего обновления.

Спасибо
Арсению Шароглазову за аудит безопасности версии 2.10, https://twitter.com/_mohemiv
Жене Лазереву за помощь в разработке версии 2.9, https://eugene-lazarev.ru/
Виктору Корейше за многочисленные улучшения в комментариях
Роману Парпалаку за движок поиска «Роза», https://written.ru/
Игорю Адаменко за локальное автосохранение и много чего ещё, https://igoradamenko.com/
Илье Страйкову за помощь в разработке версии 2.5, http://straykov.ru/
Артёму Поликарпову за прекрасную Фотораму, http://fotorama.io/
Ивану Сагалаеву за Хайлайт, http://highlightjs.org/
Мурату Шидакову за помощь с интерфейсом ввода тегов
Игорю Васильковскому за реализацию системы бекапов

а также
Саше Карпинскому, Артёму Сапегину, Ивану Звягину, Ивану Щолокову, Максиму Ильяхову, Илье Гельману, Диме Кирсанову, Жене Степанищеву, Юлии Шабунио, Диме Смирнову