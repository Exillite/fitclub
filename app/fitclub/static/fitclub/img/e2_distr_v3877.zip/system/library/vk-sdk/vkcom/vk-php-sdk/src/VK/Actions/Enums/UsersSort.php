<?php
namespace VK\Actions\Enum;

/**
 */
class UsersSort {

	/**
	 */
	const BY_DATE_REGISTERED = 1;

	/**
	 */
	const BY_RATING = 0;
}
