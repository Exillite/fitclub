<?php
namespace VK\Actions\Enum;

/**
 */
class VideoSort {

	/**
	 */
	const DATE_ADDED = 0;

	/**
	 */
	const DURATION = 1;

	/**
	 */
	const RELEVANCE = 2;
}
