<?php
namespace VK\Actions\Enum;

/**
 */
class UtilsSource {

	/**
	 */
	const VK_CC = 'vk_cc';

	/**
	 */
	const VK_LINK = 'vk_link';
}
