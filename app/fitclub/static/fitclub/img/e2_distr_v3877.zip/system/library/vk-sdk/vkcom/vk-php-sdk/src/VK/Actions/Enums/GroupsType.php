<?php
namespace VK\Actions\Enum;

/**
 */
class GroupsType {

	/**
	 */
	const EVENT = 'event';

	/**
	 */
	const GROUP = 'group';

	/**
	 */
	const PAGE = 'page';
}
