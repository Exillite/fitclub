<?php

namespace VK\CallbackApi\LongPoll\Exceptions;

class VKLongPollServerTsException extends \Exception {

}
