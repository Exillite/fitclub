<?php
namespace VK\Actions\Enum\Groups;

/**
 */
class GroupRole {

	/**
	 */
	const ADMINISTRATOR = 'administrator';

	/**
	 */
	const EDITOR = 'editor';

	/**
	 */
	const MODERATOR = 'moderator';
}
