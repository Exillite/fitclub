<?php
namespace VK\Actions\Enum;

/**
 */
class AdsLang {

	/**
	 */
	const ENGLISH = 'en';

	/**
	 */
	const RUSSIAN = 'ru';

	/**
	 */
	const UKRAINIAN = 'ua';
}
