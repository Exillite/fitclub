<?php
namespace VK\Actions\Enum\Groups;

/**
 */
class GroupMarketCurrency {

	/**
	 */
	const EURO = 978;

	/**
	 */
	const KAZAKH_TENGE = 398;

	/**
	 */
	const RUSSIAN_RUBLES = 643;

	/**
	 */
	const UKRAINIAN_HRYVNIA = 980;

	/**
	 */
	const US_DOLLARS = 840;
}
