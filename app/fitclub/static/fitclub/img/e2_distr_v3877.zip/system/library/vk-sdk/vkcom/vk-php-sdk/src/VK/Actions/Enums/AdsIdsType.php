<?php
namespace VK\Actions\Enum;

/**
 */
class AdsIdsType {

	/**
	 */
	const AD = 'ad';

	/**
	 */
	const CAMPAIGN = 'campaign';

	/**
	 */
	const CLIENT = 'client';

	/**
	 */
	const OFFICE = 'office';
}
