<?php

namespace VK\Exceptions;

class VKOAuthException extends \Exception {

}
