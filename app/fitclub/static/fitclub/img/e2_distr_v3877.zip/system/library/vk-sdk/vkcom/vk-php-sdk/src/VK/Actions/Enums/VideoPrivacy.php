<?php
namespace VK\Actions\Enum;

/**
 */
class VideoPrivacy {

	/**
	 */
	const ALL = '0';

	/**
	 */
	const FRIENDS = '1';

	/**
	 */
	const FRIENDS_OF_FRIENDS = '2';

	/**
	 */
	const ONLY_ME = '3';
}
