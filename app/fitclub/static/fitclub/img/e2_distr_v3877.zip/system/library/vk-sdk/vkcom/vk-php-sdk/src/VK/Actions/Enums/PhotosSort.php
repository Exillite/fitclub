<?php
namespace VK\Actions\Enum;

/**
 */
class PhotosSort {

	/**
	 */
	const NEW_FIRST = 'desc';

	/**
	 */
	const OLD_FIRST = 'asc';
}
