<?php
namespace VK\Actions\Enum\Groups;

/**
 */
class GroupAccess {

	/**
	 */
	const _PRIVATE = 2;

	/**
	 */
	const CLOSED = 1;

	/**
	 */
	const OPEN = 0;
}
