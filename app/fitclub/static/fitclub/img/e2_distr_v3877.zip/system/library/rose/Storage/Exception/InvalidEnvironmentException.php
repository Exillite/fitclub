<?php
/**
 * @copyright 2018 Roman Parpalak
 * @license   MIT
 */

namespace S2\Rose\Storage\Exception;

use S2\Rose\Exception\RuntimeException;

class InvalidEnvironmentException extends RuntimeException
{

}
