<?php
namespace VK\Actions\Enum;

/**
 */
class BoardSort {

	/**
	 */
	const CHRONOLOGICAL = 'asc';

	/**
	 */
	const REVERSE_CHRONOLOGICAL = 'desc';
}
