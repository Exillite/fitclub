<?php
namespace VK\Actions\Enum;

/**
 */
class UsersSex {

	/**
	 */
	const ANY = 0;

	/**
	 */
	const FEMALE = 1;

	/**
	 */
	const MALE = 2;
}
