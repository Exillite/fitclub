<?php
namespace VK\Actions\Enum;

/**
 */
class MessagesRev {

	/**
	 */
	const CHRONOLOGICAL = 1;

	/**
	 */
	const REVERSE_CHRONOLOGICAL = 0;
}
