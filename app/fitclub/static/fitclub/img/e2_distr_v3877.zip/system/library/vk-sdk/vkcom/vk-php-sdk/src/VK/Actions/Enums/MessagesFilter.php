<?php
namespace VK\Actions\Enum;

/**
 */
class MessagesFilter {

	/**
	 */
	const ALL = 'all';

	/**
	 */
	const IMPORTANT = 'important';

	/**
	 */
	const MESSAGE_REQUEST = 'message_request';

	/**
	 */
	const UNANSWERED = 'unanswered';

	/**
	 */
	const UNREAD = 'unread';
}
