<?php
namespace VK\Actions\Enum;

/**
 */
class AppsFilter {

	/**
	 */
	const _NEW = 'new';

	/**
	 */
	const FAVORITE = 'favorite';

	/**
	 */
	const FEATURED = 'featured';

	/**
	 */
	const INSTALLED = 'installed';
}
