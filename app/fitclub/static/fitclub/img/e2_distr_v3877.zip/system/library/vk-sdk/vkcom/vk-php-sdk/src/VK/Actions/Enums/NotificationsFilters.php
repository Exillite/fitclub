<?php
namespace VK\Actions\Enum;

/**
 */
class NotificationsFilters {

	/**
	 */
	const COMMENTS = 'comments';

	/**
	 */
	const FOLLOWERS = 'followers';

	/**
	 */
	const FRIENDS = 'friends';

	/**
	 */
	const LIKES = 'likes';

	/**
	 */
	const MENTIONS = 'mentions';

	/**
	 */
	const REPOSTED = 'reposted';

	/**
	 */
	const WALL = 'wall';
}
