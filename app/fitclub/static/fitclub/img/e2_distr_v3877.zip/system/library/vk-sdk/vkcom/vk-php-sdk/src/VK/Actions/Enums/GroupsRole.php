<?php
namespace VK\Actions\Enum;

/**
 */
class GroupsRole {

	/**
	 */
	const ADMINISTRATOR = 'administrator';

	/**
	 */
	const EDITOR = 'editor';

	/**
	 */
	const MODERATOR = 'moderator';
}
