<?php
namespace VK\Actions\Enum;

/**
 */
class FriendsNameCase {

	/**
	 */
	const ACCUSATIVE = 'acc';

	/**
	 */
	const DATIVE = 'dat';

	/**
	 */
	const GENITIVE = 'gen';

	/**
	 */
	const INSTRUMENTAL = 'ins';

	/**
	 */
	const NOMINATIVE = 'nom';

	/**
	 */
	const PREPOSITIONAL = 'abl';
}
