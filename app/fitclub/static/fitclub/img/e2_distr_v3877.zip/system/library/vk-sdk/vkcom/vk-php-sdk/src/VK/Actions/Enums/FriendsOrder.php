<?php
namespace VK\Actions\Enum;

/**
 */
class FriendsOrder {

	/**
	 */
	const HINTS = 'hints';

	/**
	 */
	const NAME = 'name';
}
