<?php
namespace VK\Actions\Enum;

/**
 */
class StreamingMonthlyTier {

	/**
	 */
	const TIER_1 = 'tier_1';

	/**
	 */
	const TIER_2 = 'tier_2';

	/**
	 */
	const TIER_3 = 'tier_3';

	/**
	 */
	const TIER_4 = 'tier_4';

	/**
	 */
	const TIER_5 = 'tier_5';

	/**
	 */
	const TIER_6 = 'tier_6';

	/**
	 */
	const UNLIMITED = 'unlimited';
}
