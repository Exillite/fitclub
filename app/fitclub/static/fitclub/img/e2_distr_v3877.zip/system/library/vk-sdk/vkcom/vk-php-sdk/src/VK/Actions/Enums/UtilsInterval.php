<?php
namespace VK\Actions\Enum;

/**
 */
class UtilsInterval {

	/**
	 */
	const DAY = 'day';

	/**
	 */
	const FOREVER = 'forever';

	/**
	 */
	const HOUR = 'hour';

	/**
	 */
	const MONTH = 'month';

	/**
	 */
	const WEEK = 'week';
}
