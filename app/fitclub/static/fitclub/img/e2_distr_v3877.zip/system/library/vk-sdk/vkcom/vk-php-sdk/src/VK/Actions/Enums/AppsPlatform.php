<?php
namespace VK\Actions\Enum;

/**
 */
class AppsPlatform {

	/**
	 */
	const ANDROID = 'android';

	/**
	 */
	const IOS = 'ios';

	/**
	 */
	const WEB = 'web';

	/**
	 */
	const WINPHONE = 'winphone';
}
