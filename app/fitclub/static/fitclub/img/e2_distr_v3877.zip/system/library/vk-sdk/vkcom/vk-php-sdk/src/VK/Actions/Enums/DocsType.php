<?php
namespace VK\Actions\Enum;

/**
 */
class DocsType {

	/**
	 */
	const AUDIO_MESSAGE = 'audio_message';

	/**
	 */
	const DOC = 'doc';

	/**
	 */
	const GRAFFITI = 'graffiti';
}
