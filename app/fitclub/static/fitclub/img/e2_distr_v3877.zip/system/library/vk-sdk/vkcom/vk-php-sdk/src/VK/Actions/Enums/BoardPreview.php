<?php
namespace VK\Actions\Enum;

/**
 */
class BoardPreview {

	/**
	 */
	const FIRST = 1;

	/**
	 */
	const LAST = 2;

	/**
	 */
	const NONE = 0;
}
