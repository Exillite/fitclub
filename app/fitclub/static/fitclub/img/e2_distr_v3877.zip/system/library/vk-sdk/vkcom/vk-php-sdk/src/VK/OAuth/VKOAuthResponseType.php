<?php

namespace VK\OAuth;

class VKOAuthResponseType {
  public const CODE  = 'code';
  public const TOKEN = 'token';
}
