<?php
namespace VK\Actions\Enum;

/**
 */
class LikesFilter {

	/**
	 */
	const COPIES = 'copies';

	/**
	 */
	const LIKES = 'likes';
}
