<?php
namespace VK\Actions\Enum;

/**
 */
class UsersType {

	/**
	 */
	const ADVERTISMENT = 'advertisment';

	/**
	 */
	const INSULT = 'insult';

	/**
	 */
	const PORN = 'porn';

	/**
	 */
	const SPAM = 'spam';
}
