<?php
namespace VK\Actions\Enum;

/**
 */
class GroupsAccess {

	/**
	 */
	const CLOSED = 1;

	/**
	 */
	const OPEN = 0;

	/**
	 */
	const PRIVATE = 2;
}
