<?php
namespace VK\Actions\Enum;

/**
 */
class AppsSort {

	/**
	 */
	const CREATE_DATE = 'create_date';

	/**
	 */
	const GROWTH_RATE = 'growth_rate';

	/**
	 */
	const POPULAR_TODAY = 'popular_today';

	/**
	 */
	const POPULAR_WEEK = 'popular_week';

	/**
	 */
	const VISITORS = 'visitors';
}
