<?php
namespace VK\Actions\Enum;

/**
 */
class MarketStatus {

	/**
	 */
	const _0 = 0;

	/**
	 */
	const _2 = 2;
}
