<?php
namespace VK\Actions\Enum;

/**
 */
class GroupsFilter {

	/**
	 */
	const FRIENDS = 'friends';

	/**
	 */
	const UNSURE = 'unsure';
}
