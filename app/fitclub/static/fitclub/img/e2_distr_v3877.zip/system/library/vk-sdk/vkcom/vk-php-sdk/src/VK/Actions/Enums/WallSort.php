<?php
namespace VK\Actions\Enum;

/**
 */
class WallSort {

	/**
	 */
	const CHRONOLOGICAL = 'asc';

	/**
	 */
	const REVERSE_CHRONOLOGICAL = 'desc';
}
