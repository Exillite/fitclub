<?php
namespace VK\Actions\Enum\Groups;

/**
 */
class GroupAgeLimits {

	/**
	 */
	const _16_PLUS = 2;

	/**
	 */
	const _18_PLUS = 3;

	/**
	 */
	const UNLIMITED = 1;
}
