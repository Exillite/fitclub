<?php
namespace VK\Actions\Enum;

/**
 */
class AppsType {

	/**
	 */
	const INVITE = 'invite';

	/**
	 */
	const REQUEST = 'request';
}
