<?php
/**
 * @copyright 2017-2020 Roman Parpalak
 * @license   MIT
 */

namespace S2\Rose\Exception;

class LogicException extends \LogicException implements ExceptionInterface
{

}
