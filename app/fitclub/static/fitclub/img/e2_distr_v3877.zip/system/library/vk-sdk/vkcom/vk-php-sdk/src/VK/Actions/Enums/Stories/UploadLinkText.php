<?php
namespace VK\Actions\Enum\Stories;

/**
 */
class UploadLinkText {

	/**
	 */
	const BOOK = 'book';

	/**
	 */
	const BUY = 'buy';

	/**
	 */
	const CONTACT = 'contact';

	/**
	 */
	const ENROLL = 'enroll';

	/**
	 */
	const FILL = 'fill';

	/**
	 */
	const GO_TO = 'go_to';

	/**
	 */
	const INSTALL = 'install';

	/**
	 */
	const LEARN_MORE = 'learn_more';

	/**
	 */
	const MORE = 'more';

	/**
	 */
	const OPEN = 'open';

	/**
	 */
	const ORDER = 'order';

	/**
	 */
	const PLAY = 'play';

	/**
	 */
	const READ = 'read';

	/**
	 */
	const SIGNUP = 'signup';

	/**
	 */
	const TICKET = 'ticket';

	/**
	 */
	const TO_STORE = 'to_store';

	/**
	 */
	const VIEW = 'view';

	/**
	 */
	const VOTE = 'vote';

	/**
	 */
	const WATCH = 'watch';

	/**
	 */
	const WRITE = 'write';
}
