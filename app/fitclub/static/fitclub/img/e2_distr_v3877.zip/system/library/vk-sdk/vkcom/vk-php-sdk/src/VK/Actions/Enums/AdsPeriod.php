<?php
namespace VK\Actions\Enum;

/**
 */
class AdsPeriod {

	/**
	 */
	const DAY = 'day';

	/**
	 */
	const MONTH = 'month';

	/**
	 */
	const OVERALL = 'overall';
}
