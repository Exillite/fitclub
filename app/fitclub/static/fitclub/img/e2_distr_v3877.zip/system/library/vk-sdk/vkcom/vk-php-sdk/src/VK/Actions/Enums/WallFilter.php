<?php
namespace VK\Actions\Enum;

/**
 */
class WallFilter {

	/**
	 */
	const ALL = 'all';

	/**
	 */
	const OTHERS = 'others';

	/**
	 */
	const OWNER = 'owner';

	/**
	 */
	const POSTPONED = 'postponed';

	/**
	 */
	const SUGGESTS = 'suggests';
}
