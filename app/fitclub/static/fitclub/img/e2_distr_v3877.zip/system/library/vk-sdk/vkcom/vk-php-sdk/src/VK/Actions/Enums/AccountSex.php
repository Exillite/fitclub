<?php
namespace VK\Actions\Enum;

/**
 */
class AccountSex {

	/**
	 */
	const FEMALE = 1;

	/**
	 */
	const MALE = 2;

	/**
	 */
	const UNDEFINED = 0;
}
