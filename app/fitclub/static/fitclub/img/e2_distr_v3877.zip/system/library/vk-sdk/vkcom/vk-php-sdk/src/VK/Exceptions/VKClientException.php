<?php

namespace VK\Exceptions;

class VKClientException extends \Exception {
    
}
