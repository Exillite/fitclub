<?php
namespace VK\Actions\Enum;

/**
 */
class FriendsFilter {

	/**
	 */
	const CONTACTS = 'contacts';

	/**
	 */
	const MUTUAL = 'mutual';

	/**
	 */
	const MUTUAL_CONTACTS = 'mutual_contacts';
}
