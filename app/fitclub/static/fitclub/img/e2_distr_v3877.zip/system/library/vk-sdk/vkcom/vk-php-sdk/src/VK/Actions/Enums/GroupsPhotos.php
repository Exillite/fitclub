<?php
namespace VK\Actions\Enum;

/**
 */
class GroupsPhotos {

	/**
	 */
	const DISABLED = 0;

	/**
	 */
	const LIMITED = 2;

	/**
	 */
	const OPEN = 1;
}
