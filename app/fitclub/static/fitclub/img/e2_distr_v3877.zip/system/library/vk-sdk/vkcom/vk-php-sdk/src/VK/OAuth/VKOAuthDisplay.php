<?php

namespace VK\OAuth;

class VKOAuthDisplay {
  public const PAGE   = 'page';
  public const POPUP  = 'popup';
  public const MOBILE = 'mobile';
}
