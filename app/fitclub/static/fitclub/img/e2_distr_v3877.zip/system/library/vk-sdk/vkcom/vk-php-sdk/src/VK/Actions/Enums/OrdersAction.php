<?php
namespace VK\Actions\Enum;

/**
 */
class OrdersAction {

	/**
	 */
	const CANCEL = 'cancel';

	/**
	 */
	const CHARGE = 'charge';

	/**
	 */
	const REFUND = 'refund';
}
