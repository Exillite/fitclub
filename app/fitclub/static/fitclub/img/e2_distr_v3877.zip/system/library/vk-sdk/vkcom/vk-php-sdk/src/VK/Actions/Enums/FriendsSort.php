<?php
namespace VK\Actions\Enum;

/**
 */
class FriendsSort {

	/**
	 */
	const DATE = 0;

	/**
	 */
	const MUTUAL = 1;
}
