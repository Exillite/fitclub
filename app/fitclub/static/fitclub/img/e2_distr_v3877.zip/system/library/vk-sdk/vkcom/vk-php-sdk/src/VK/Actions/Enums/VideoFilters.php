<?php
namespace VK\Actions\Enum;

/**
 */
class VideoFilters {

	/**
	 */
	const LONG = 'long';

	/**
	 */
	const SHORT = 'short';

	/**
	 */
	const VIMEO = 'vimeo';

	/**
	 */
	const YOUTUBE = 'youtube';
}
