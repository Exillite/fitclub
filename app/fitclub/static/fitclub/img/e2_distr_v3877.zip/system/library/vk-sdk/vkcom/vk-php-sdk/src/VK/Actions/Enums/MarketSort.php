<?php
namespace VK\Actions\Enum;

/**
 */
class MarketSort {

	/**
	 */
	const _0 = 0;

	/**
	 */
	const _1 = 1;

	/**
	 */
	const _2 = 2;

	/**
	 */
	const _3 = 3;
}
