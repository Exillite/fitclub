<?php
namespace VK\Actions\Enum;

/**
 */
class MarketRev {

	/**
	 */
	const NORMAL = 0;

	/**
	 */
	const REVERSE = 1;
}
