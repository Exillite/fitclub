<?php

namespace VK\CallbackApi\LongPoll\Exceptions;

class VKLongPollServerKeyExpiredException extends \Exception {

}
