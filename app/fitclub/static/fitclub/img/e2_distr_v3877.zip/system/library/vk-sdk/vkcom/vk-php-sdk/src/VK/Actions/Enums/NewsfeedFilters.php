<?php
namespace VK\Actions\Enum;

/**
 */
class NewsfeedFilters {

	/**
	 */
	const NOTE = 'note';

	/**
	 */
	const PHOTO = 'photo';

	/**
	 */
	const POST = 'post';

	/**
	 */
	const TOPIC = 'topic';

	/**
	 */
	const VIDEO = 'video';
}
