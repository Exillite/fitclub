<?php
namespace VK\Actions\Enum;

/**
 */
class PagesEdit {

	/**
	 */
	const ALL = 2;

	/**
	 */
	const MANAGERS = 0;

	/**
	 */
	const MEMBERS = 1;
}
