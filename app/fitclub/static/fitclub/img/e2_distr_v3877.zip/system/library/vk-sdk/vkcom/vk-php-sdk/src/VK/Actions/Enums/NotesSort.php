<?php
namespace VK\Actions\Enum;

/**
 */
class NotesSort {

	/**
	 */
	const _0 = 0;

	/**
	 */
	const _1 = 1;
}
