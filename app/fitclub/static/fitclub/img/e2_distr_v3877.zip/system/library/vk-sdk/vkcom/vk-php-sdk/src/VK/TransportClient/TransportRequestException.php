<?php

namespace VK\TransportClient;

class TransportRequestException extends \Exception {

}
